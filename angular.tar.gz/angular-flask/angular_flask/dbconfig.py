db_params_map = {
    'dbname': 'crawler',
    'user': 'postgres',
    'password': '@hawkerIndia',
    'host': '188.166.247.169',
}